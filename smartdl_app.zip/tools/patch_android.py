#!/usr/bin/env python3
"""بيعدّل AndroidManifest.xml اللي flutter create عمله: صلاحيات + خدمة التحميل في الخلفية."""
import pathlib
import re

mf = pathlib.Path("android/app/src/main/AndroidManifest.xml")
s = mf.read_text(encoding="utf-8")

perms = [
    "android.permission.INTERNET",
    "android.permission.ACCESS_NETWORK_STATE",
    "android.permission.WAKE_LOCK",
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.FOREGROUND_SERVICE",
    "android.permission.FOREGROUND_SERVICE_DATA_SYNC",
]
add = "".join(
    f'    <uses-permission android:name="{p}" />\n' for p in perms if p not in s
)
s = re.sub(r"(<manifest[^>]*>)", lambda m: m.group(1) + "\n" + add, s, count=1)

# المتصفح المدمج محتاج يفتح مواقع http عادية كمان
if "usesCleartextTraffic" not in s:
    s = s.replace("<application", '<application\n        android:usesCleartextTraffic="true"', 1)

# اسم التطبيق
s = re.sub(r'android:label="[^"]*"', 'android:label="SmartDL"', s, count=1)

service = (
    '    <service\n'
    '        android:name="com.pravera.flutter_foreground_task.service.ForegroundService"\n'
    '        android:foregroundServiceType="dataSync"\n'
    '        android:exported="false" />\n'
)
if "ForegroundService" not in s:
    s = s.replace("</application>", service + "  </application>", 1)

mf.write_text(s, encoding="utf-8")
print("AndroidManifest patched OK")
