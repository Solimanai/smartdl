import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import 'manager.dart';
import 'settings.dart';

/// مراجع عامة بسيطة للتطبيق.
class App {
  static late AppSettings settings;
  static late DownloadManager manager;
  static WebViewEnvironment? webEnv;
}
