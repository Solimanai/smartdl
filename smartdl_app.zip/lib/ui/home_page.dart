import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:open_filex/open_filex.dart';
import 'package:share_plus/share_plus.dart';

import '../app_state.dart';
import '../engine.dart';
import '../models.dart';
import '../utils.dart';
import 'browser_page.dart';
import 'settings_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  late final TabController _tabs = TabController(length: 3, vsync: this);
  String? _lastClip;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkClipboard());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _tabs.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _checkClipboard();
  }

  // ───────── الرابط المنسوخ ─────────

  Future<void> _checkClipboard() async {
    try {
      final d = await Clipboard.getData(Clipboard.kTextPlain);
      final t = d?.text?.trim();
      if (t == null || t == _lastClip || !isHttpUrl(t)) return;
      _lastClip = t;
      if (App.manager.items.any((i) => i.url == t)) return;
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('لقيت رابط منسوخ: ${shorten(t, 40)}'),
        duration: const Duration(seconds: 8),
        action: SnackBarAction(label: 'تحميل', onPressed: () => _addLinks([t])),
      ));
    } catch (_) {}
  }

  // ───────── إضافة روابط ─────────

  Future<void> _showAddDialog() async {
    final ctl = TextEditingController();
    final result = await showDialog<List<String>>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إضافة رابط'),
        content: SizedBox(
          width: 460,
          child: TextField(
            controller: ctl,
            autofocus: true,
            minLines: 3,
            maxLines: 6,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(
              hintText: 'الصق رابط أو أكتر (كل رابط في سطر)',
              border: OutlineInputBorder(),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              final d = await Clipboard.getData(Clipboard.kTextPlain);
              if (d?.text != null) ctl.text = d!.text!;
            },
            child: const Text('لصق'),
          ),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
            onPressed: () {
              final urls = RegExp(r'https?://\S+')
                  .allMatches(ctl.text)
                  .map((m) => m.group(0)!)
                  .toList();
              Navigator.pop(ctx, urls);
            },
            child: const Text('تحميل'),
          ),
        ],
      ),
    );
    if (result != null && result.isNotEmpty) await _addLinks(result);
  }

  Future<void> _addLinks(List<String> urls) async {
    final messenger = ScaffoldMessenger.of(context);
    if (urls.length == 1) {
      // لو الرابط صفحة ويب مش ملف، اعرض فتحه في المتصفح
      try {
        messenger.showSnackBar(const SnackBar(
          content: Text('بفحص الرابط...'),
          duration: Duration(seconds: 2),
        ));
        final pr = await probeUrl(urls.first, {}).timeout(const Duration(seconds: 25));
        if (pr.isHtml) {
          if (!mounted) return;
          final open = await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
              title: const Text('الرابط ده صفحة ويب'),
              content: const Text(
                  'مش ملف مباشر. تحب تفتحه في المتصفح المدمج وتدوس على زر التحميل جواه؟'),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    child: const Text('لا')),
                FilledButton(
                    onPressed: () => Navigator.pop(ctx, true),
                    child: const Text('افتح في المتصفح')),
              ],
            ),
          );
          if (open == true && mounted) _openBrowser(urls.first);
          return;
        }
      } catch (_) {
        // لو الفحص فشل (مفيش نت مثلاً) ضيفه عادي والمحرك هيعيد المحاولة
      }
    }
    for (final u in urls) {
      await App.manager.add(u);
    }
    if (!mounted) return;
    messenger.hideCurrentSnackBar();
    messenger.showSnackBar(SnackBar(content: Text('اتضاف ${urls.length} للتحميلات')));
  }

  void _openBrowser([String? url]) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => BrowserPage(initialUrl: url)),
    );
  }

  // ───────── واجهة ─────────

  @override
  Widget build(BuildContext context) {
    final m = App.manager;
    return AnimatedBuilder(
      animation: m,
      builder: (context, _) {
        final all = m.items.reversed.toList();
        List<DownloadItem> pick(int tab) {
          if (tab == 0) return all;
          if (tab == 1) {
            return all.where((i) => i.status != DlStatus.completed).toList();
          }
          return all.where((i) => i.status == DlStatus.completed).toList();
        }

        return Scaffold(
          appBar: AppBar(
            title: const Text('SmartDL'),
            actions: [
              IconButton(
                tooltip: 'المتصفح',
                icon: const Icon(Icons.public),
                onPressed: () => _openBrowser(),
              ),
              PopupMenuButton<String>(
                onSelected: (v) {
                  if (v == 'pause') m.pauseAll();
                  if (v == 'resume') m.resumeAll();
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'pause', child: Text('إيقاف الكل')),
                  PopupMenuItem(value: 'resume', child: Text('استئناف الكل')),
                ],
              ),
              IconButton(
                tooltip: 'الإعدادات',
                icon: const Icon(Icons.settings),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SettingsPage()),
                ),
              ),
            ],
            bottom: TabBar(
              controller: _tabs,
              tabs: const [Tab(text: 'الكل'), Tab(text: 'جارٍ'), Tab(text: 'مكتمل')],
            ),
          ),
          body: TabBarView(
            controller: _tabs,
            children: [for (var i = 0; i < 3; i++) _buildList(pick(i))],
          ),
          bottomNavigationBar: m.activeCount > 0
              ? Container(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  child: SafeArea(
                    top: false,
                    child: Row(
                      children: [
                        const Icon(Icons.speed, size: 18),
                        const SizedBox(width: 8),
                        Text('${m.activeCount} جارٍ • ${humanBytes(m.totalSpeed)}/ث'),
                      ],
                    ),
                  ),
                )
              : null,
          floatingActionButton: FloatingActionButton.extended(
            onPressed: _showAddDialog,
            icon: const Icon(Icons.add_link),
            label: const Text('إضافة رابط'),
          ),
        );
      },
    );
  }

  Widget _buildList(List<DownloadItem> list) {
    if (list.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.download_for_offline_outlined,
                  size: 72, color: Theme.of(context).colorScheme.outline),
              const SizedBox(height: 12),
              const Text('مفيش تحميلات هنا', style: TextStyle(fontSize: 16)),
              const SizedBox(height: 16),
              Wrap(
                spacing: 12,
                runSpacing: 8,
                alignment: WrapAlignment.center,
                children: [
                  FilledButton.icon(
                    onPressed: _showAddDialog,
                    icon: const Icon(Icons.add_link),
                    label: const Text('الصق رابط'),
                  ),
                  OutlinedButton.icon(
                    onPressed: () => _openBrowser(),
                    icon: const Icon(Icons.public),
                    label: const Text('افتح المتصفح'),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.only(bottom: 96, top: 4),
      itemCount: list.length,
      itemBuilder: (_, i) => _Tile(
        item: list[i],
        onMenu: (v) => _onMenu(list[i], v),
      ),
    );
  }

  Future<void> _onMenu(DownloadItem it, String v) async {
    final m = App.manager;
    switch (v) {
      case 'copy':
        await Clipboard.setData(ClipboardData(text: it.url));
        if (mounted) {
          ScaffoldMessenger.of(context)
              .showSnackBar(const SnackBar(content: Text('اتنسخ الرابط')));
        }
        break;
      case 'folder':
        if (Platform.isWindows) {
          await Process.run('explorer.exe', ['/select,${it.path}']);
        }
        break;
      case 'share':
        await Share.shareXFiles([XFile(it.path)]);
        break;
      case 'restart':
        await m.restart(it.id);
        break;
      case 'remove':
        await m.remove(it.id, deleteFile: false);
        break;
      case 'delete':
        final ok = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('حذف الملف؟'),
            content: Text('هيتمسح "${it.fileName}" من الجهاز كمان.'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text('إلغاء')),
              FilledButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  child: const Text('حذف')),
            ],
          ),
        );
        if (ok == true) await m.remove(it.id, deleteFile: true);
        break;
    }
  }
}

IconData _iconFor(String name) {
  final n = name.toLowerCase();
  bool any(List<String> e) => e.any(n.endsWith);
  if (any(['.mp4', '.mkv', '.avi', '.mov', '.webm'])) return Icons.movie_outlined;
  if (any(['.mp3', '.m4a', '.flac', '.wav', '.aac'])) return Icons.music_note_outlined;
  if (any(['.zip', '.rar', '.7z', '.tar', '.gz'])) return Icons.folder_zip_outlined;
  if (any(['.apk'])) return Icons.android;
  if (any(['.exe', '.msi'])) return Icons.settings_applications_outlined;
  if (any(['.pdf'])) return Icons.picture_as_pdf_outlined;
  if (any(['.jpg', '.jpeg', '.png', '.gif', '.webp'])) return Icons.image_outlined;
  if (any(['.iso'])) return Icons.album_outlined;
  return Icons.insert_drive_file_outlined;
}

class _Tile extends StatelessWidget {
  const _Tile({required this.item, required this.onMenu});

  final DownloadItem item;
  final void Function(String) onMenu;

  String _subtitle() {
    final it = item;
    final total = it.totalBytes > 0 ? humanBytes(it.totalBytes) : '؟';
    switch (it.status) {
      case DlStatus.downloading:
        if (it.note != null) return it.note!;
        final eta = it.totalBytes > 0 && it.speed > 1
            ? humanEta((it.totalBytes - it.bytesDone) / it.speed)
            : '--';
        return '${humanBytes(it.bytesDone)} / $total  •  ${humanBytes(it.speed)}/ث  •  باقي $eta';
      case DlStatus.queued:
        return it.note ?? 'في الانتظار';
      case DlStatus.paused:
        return 'متوقف مؤقتًا  •  ${humanBytes(it.bytesDone)} / $total';
      case DlStatus.completed:
        return 'مكتمل  •  ${humanBytes(it.totalBytes)}';
      case DlStatus.failed:
        return it.error ?? 'فشل التحميل';
    }
  }

  @override
  Widget build(BuildContext context) {
    final it = item;
    final cs = Theme.of(context).colorScheme;
    final isDone = it.status == DlStatus.completed;
    final failed = it.status == DlStatus.failed;

    Widget action;
    if (isDone) {
      action = IconButton(
        tooltip: 'فتح',
        icon: const Icon(Icons.open_in_new),
        onPressed: () => OpenFilex.open(it.path),
      );
    } else if (it.status == DlStatus.paused || failed) {
      action = IconButton(
        tooltip: 'استئناف',
        icon: const Icon(Icons.play_arrow),
        onPressed: () => App.manager.resume(it.id),
      );
    } else {
      action = IconButton(
        tooltip: 'إيقاف مؤقت',
        icon: const Icon(Icons.pause),
        onPressed: () => App.manager.pause(it.id),
      );
    }

    return Card(
      margin: const EdgeInsets.fromLTRB(12, 6, 12, 6),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 12, 4, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(_iconFor(it.fileName), size: 32, color: cs.primary),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    it.fileName,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                action,
                PopupMenuButton<String>(
                  onSelected: onMenu,
                  itemBuilder: (_) => [
                    const PopupMenuItem(value: 'copy', child: Text('نسخ الرابط')),
                    if (isDone && Platform.isWindows)
                      const PopupMenuItem(value: 'folder', child: Text('إظهار في المجلد')),
                    if (isDone && !Platform.isWindows)
                      const PopupMenuItem(value: 'share', child: Text('مشاركة / حفظ في مكان تاني')),
                    const PopupMenuItem(value: 'restart', child: Text('إعادة من الصفر')),
                    const PopupMenuItem(value: 'remove', child: Text('إزالة من القائمة')),
                    const PopupMenuItem(value: 'delete', child: Text('حذف مع الملف')),
                  ],
                ),
              ],
            ),
            if (!isDone) ...[
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.only(left: 8),
                child: LinearProgressIndicator(
                  value: it.status == DlStatus.downloading && it.totalBytes == 0
                      ? null
                      : (it.progress ?? 0),
                  minHeight: 6,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ],
            const SizedBox(height: 6),
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: Text(
                _subtitle(),
                style: TextStyle(
                  fontSize: 12,
                  color: failed ? cs.error : cs.onSurfaceVariant,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
