import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../app_state.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final s = App.settings;
  String _dir = '';

  static const _limits = <int, String>{
    0: 'بدون حد',
    256: '256 KB/ث',
    512: '512 KB/ث',
    1024: '1 MB/ث',
    2048: '2 MB/ث',
    5120: '5 MB/ث',
    10240: '10 MB/ث',
  };

  @override
  void initState() {
    super.initState();
    s.resolveDir().then((d) {
      if (mounted) setState(() => _dir = d);
    });
  }

  Future<void> _pickDir() async {
    final d = await FilePicker.platform.getDirectoryPath();
    if (d != null) {
      s.customDir = d;
      await s.save();
      if (mounted) setState(() => _dir = d);
    }
  }

  Future<void> _resetDir() async {
    s.customDir = null;
    await s.save();
    final d = await s.resolveDir();
    if (mounted) setState(() => _dir = d);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8),
        children: [
          ListTile(
            title: const Text('عدد الاتصالات لكل ملف'),
            subtitle: Text('${s.connections}  (كل ما زاد زادت السرعة، لكن بعض السيرفرات بتحظر الكتير)'),
          ),
          Slider(
            value: s.connections.toDouble(),
            min: 1,
            max: 32,
            divisions: 31,
            label: '${s.connections}',
            onChanged: (v) => setState(() => s.connections = v.round()),
            onChangeEnd: (_) => s.save(),
          ),
          ListTile(
            title: const Text('عدد التحميلات في نفس الوقت'),
            subtitle: Text('${s.maxConcurrent}'),
          ),
          Slider(
            value: s.maxConcurrent.toDouble(),
            min: 1,
            max: 10,
            divisions: 9,
            label: '${s.maxConcurrent}',
            onChanged: (v) => setState(() => s.maxConcurrent = v.round()),
            onChangeEnd: (_) => s.save(),
          ),
          ListTile(
            title: const Text('أقصى سرعة'),
            trailing: DropdownButton<int>(
              value: _limits.containsKey(s.speedLimitKB) ? s.speedLimitKB : 0,
              items: [
                for (final e in _limits.entries)
                  DropdownMenuItem(value: e.key, child: Text(e.value)),
              ],
              onChanged: (v) async {
                if (v == null) return;
                setState(() => s.speedLimitKB = v);
                await s.save();
              },
            ),
          ),
          const Divider(),
          ListTile(
            title: const Text('مكان حفظ الملفات'),
            subtitle: Text(_dir, textDirection: TextDirection.ltr),
            trailing: Platform.isWindows
                ? Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (s.customDir != null)
                        IconButton(
                          tooltip: 'الافتراضي',
                          icon: const Icon(Icons.restore),
                          onPressed: _resetDir,
                        ),
                      IconButton(
                        tooltip: 'تغيير',
                        icon: const Icon(Icons.folder_open),
                        onPressed: _pickDir,
                      ),
                    ],
                  )
                : null,
          ),
          if (Platform.isAndroid)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(
                'على أندرويد الملفات بتتحفظ في مجلد التطبيق. افتحها من القائمة، أو اختار '
                '"مشاركة / حفظ في مكان تاني" من قايمة الملف.',
                style: TextStyle(fontSize: 12),
              ),
            ),
          const Divider(),
          SwitchListTile(
            title: const Text('حظر النوافذ المنبثقة (إعلانات)'),
            subtitle: const Text('في المتصفح المدمج. تقدر تفتح أي نافذة اتحظرت بإيدك.'),
            value: s.blockPopups,
            onChanged: (v) async {
              setState(() => s.blockPopups = v);
              await s.save();
            },
          ),
          SwitchListTile(
            title: const Text('اسألني قبل بدء التحميل الملتقط'),
            subtitle: const Text('لو مقفولة، أي تحميل المتصفح يلقطه يبدأ على طول.'),
            value: s.confirmCapture,
            onChanged: (v) async {
              setState(() => s.confirmCapture = v);
              await s.save();
            },
          ),
        ],
      ),
    );
  }
}
