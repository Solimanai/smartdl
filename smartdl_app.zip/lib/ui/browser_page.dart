import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import '../app_state.dart';
import '../utils.dart';

/// متصفح مدمج: افتح الموقع، اتخطى الإعلانات، دوس زر التحميل وهو بيلقطه ويكمل بمحرك SmartDL.
class BrowserPage extends StatefulWidget {
  const BrowserPage({super.key, this.initialUrl});

  final String? initialUrl;

  @override
  State<BrowserPage> createState() => _BrowserPageState();
}

class _BrowserPageState extends State<BrowserPage> {
  InAppWebViewController? _c;
  final _urlCtl = TextEditingController();
  double _progress = 0;
  String _current = '';
  bool _canBack = false;
  int _blocked = 0;
  bool _sheetOpen = false;

  /// ملفات ميديا لقيناها في الشبكة (أندرويد بس): url -> headers
  final Map<String, Map<String, String>> _found = {};

  static const _mediaExt = {
    'mp4', 'mkv', 'webm', 'avi', 'mov', 'mp3', 'm4a', 'aac', 'flac', 'wav',
    'zip', 'rar', '7z', 'apk', 'pdf', 'iso', 'exe', 'msi',
  };

  String _normalize(String input) {
    final t = input.trim();
    if (t.isEmpty) return 'https://www.google.com';
    if (RegExp(r'^[a-zA-Z][a-zA-Z0-9+.-]*://').hasMatch(t)) return t;
    if (!t.contains(' ') && t.contains('.')) return 'https://$t';
    return 'https://www.google.com/search?q=${Uri.encodeQueryComponent(t)}';
  }

  void _go(String input) {
    _c?.loadUrl(urlRequest: URLRequest(url: WebUri(_normalize(input))));
    FocusScope.of(context).unfocus();
  }

  void _snack(String msg, {SnackBarAction? action}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg), action: action));
  }

  Future<String> _cookiesFor(String url) async {
    try {
      final list = await CookieManager.instance(webViewEnvironment: App.webEnv)
          .getCookies(url: WebUri(url), webViewController: _c);
      return list.map((c) => '${c.name}=${c.value}').join('; ');
    } catch (_) {
      return '';
    }
  }

  /// بيعرض ورقة تأكيد (أو بيبدأ على طول حسب الإعدادات) ويضيف التحميل للمحرك.
  Future<void> _offer(
    String url,
    Map<String, String> headers, {
    String? name,
    int size = 0,
  }) async {
    final u = Uri.tryParse(url);
    if (u == null || !(u.scheme == 'http' || u.scheme == 'https')) {
      _snack('نوع الرابط (${u?.scheme ?? '?'}) مش مدعوم للتحميل.');
      return;
    }
    if (_sheetOpen) return;

    final h = {...headers};
    final cookies = await _cookiesFor(url);
    if (cookies.isNotEmpty) h['Cookie'] = cookies;
    if (_current.isNotEmpty) h.putIfAbsent('Referer', () => _current);

    if (!App.settings.confirmCapture) {
      await App.manager.add(url, headers: h, fileName: name);
      _addedSnack();
      return;
    }
    if (!mounted) return;

    _sheetOpen = true;
    final ctl = TextEditingController(text: name ?? nameFromUrl(url));
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(16, 4, 16, 16 + MediaQuery.of(ctx).viewInsets.bottom),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('تم التقاط تحميل',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(
              controller: ctl,
              decoration: const InputDecoration(
                labelText: 'اسم الملف',
                border: OutlineInputBorder(),
              ),
            ),
            if (size > 0) ...[
              const SizedBox(height: 8),
              Text('الحجم: ${humanBytes(size)}'),
            ],
            const SizedBox(height: 4),
            Text(shorten(url, 70),
                textDirection: TextDirection.ltr,
                style: const TextStyle(fontSize: 11, color: Colors.grey)),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    child: const Text('إلغاء'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 2,
                  child: FilledButton.icon(
                    onPressed: () => Navigator.pop(ctx, true),
                    icon: const Icon(Icons.download),
                    label: const Text('ابدأ التحميل'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
    _sheetOpen = false;
    if (ok == true) {
      final n = ctl.text.trim();
      await App.manager.add(url, headers: h, fileName: n.isEmpty ? null : n);
      _addedSnack();
    }
  }

  void _addedSnack() {
    _snack(
      'اتضاف للتحميلات ✓',
      action: SnackBarAction(
        label: 'عرض',
        onPressed: () {
          if (mounted) Navigator.pop(context);
        },
      ),
    );
  }

  void _showFound() {
    if (_found.isEmpty) {
      _snack('لسه ملقيناش ملفات ميديا في الصفحة. شغّل الفيديو أو دوس تحميل.');
      return;
    }
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => ListView(
        shrinkWrap: true,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Text('ملفات لقيناها في الصفحة',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ),
          for (final e in _found.entries.toList().reversed)
            ListTile(
              leading: const Icon(Icons.insert_drive_file_outlined),
              title: Text(nameFromUrl(e.key), maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text(shorten(e.key, 60), textDirection: TextDirection.ltr),
              trailing: const Icon(Icons.download),
              onTap: () {
                Navigator.pop(ctx);
                _offer(e.key, e.value);
              },
            ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _urlCtl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final blockOn = App.settings.blockPopups;
    return PopScope(
      canPop: !_canBack,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _c?.goBack();
      },
      child: Scaffold(
        appBar: AppBar(
          titleSpacing: 0,
          title: SizedBox(
            height: 40,
            child: TextField(
              controller: _urlCtl,
              textDirection: TextDirection.ltr,
              keyboardType: TextInputType.url,
              textInputAction: TextInputAction.go,
              onSubmitted: _go,
              onTap: () => _urlCtl.selection =
                  TextSelection(baseOffset: 0, extentOffset: _urlCtl.text.length),
              decoration: InputDecoration(
                hintText: 'ابحث أو اكتب عنوان',
                filled: true,
                contentPadding: const EdgeInsets.symmetric(horizontal: 14),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          actions: [
            IconButton(
              tooltip: blockOn ? 'حظر الإعلانات المنبثقة: شغال' : 'حظر الإعلانات المنبثقة: مقفول',
              icon: Badge(
                label: Text('$_blocked'),
                isLabelVisible: _blocked > 0,
                child: Icon(blockOn ? Icons.shield : Icons.shield_outlined),
              ),
              onPressed: () async {
                App.settings.blockPopups = !App.settings.blockPopups;
                await App.settings.save();
                if (mounted) setState(() {});
              },
            ),
            IconButton(
              tooltip: 'ملفات ملقوطة من الصفحة',
              icon: Badge(
                label: Text('${_found.length}'),
                isLabelVisible: _found.isNotEmpty,
                child: const Icon(Icons.video_library_outlined),
              ),
              onPressed: _showFound,
            ),
            PopupMenuButton<String>(
              onSelected: (v) async {
                if (v == 'dl') _offer(_current, {});
                if (v == 'copy') {
                  await Clipboard.setData(ClipboardData(text: _current));
                  _snack('اتنسخ الرابط');
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'dl', child: Text('تحميل رابط الصفحة دي كملف')),
                PopupMenuItem(value: 'copy', child: Text('نسخ الرابط')),
              ],
            ),
          ],
        ),
        body: Column(
          children: [
            if (_progress < 1) LinearProgressIndicator(value: _progress, minHeight: 3),
            Expanded(
              child: InAppWebView(
                webViewEnvironment: App.webEnv,
                initialUrlRequest: URLRequest(
                  url: WebUri(_normalize(widget.initialUrl ?? 'https://www.google.com')),
                ),
                initialSettings: InAppWebViewSettings(
                  javaScriptEnabled: true,
                  supportMultipleWindows: true,
                  javaScriptCanOpenWindowsAutomatically: true,
                  useOnDownloadStart: true,
                  useShouldOverrideUrlLoading: true,
                  useShouldInterceptRequest: Platform.isAndroid,
                  thirdPartyCookiesEnabled: true,
                  mediaPlaybackRequiresUserGesture: true,
                ),
                onWebViewCreated: (c) => _c = c,
                onProgressChanged: (c, p) {
                  if (mounted) setState(() => _progress = p / 100);
                },
                onUpdateVisitedHistory: (c, url, isReload) async {
                  final back = await c.canGoBack();
                  if (!mounted) return;
                  setState(() {
                    _current = url?.toString() ?? _current;
                    _urlCtl.text = _current;
                    _canBack = back;
                  });
                },

                // نوافذ الإعلانات المنبثقة
                onCreateWindow: (c, action) async {
                  final target = action.request.url;
                  if (App.settings.blockPopups) {
                    setState(() => _blocked++);
                    _snack(
                      'اتحظرت نافذة منبثقة',
                      action: target == null
                          ? null
                          : SnackBarAction(
                              label: 'افتحها',
                              onPressed: () =>
                                  c.loadUrl(urlRequest: URLRequest(url: target)),
                            ),
                    );
                  } else if (target != null) {
                    c.loadUrl(urlRequest: URLRequest(url: target));
                  }
                  return false;
                },

                // امنع فتح تطبيقات تانية (intent://, market:// ...) اللي الإعلانات بتستخدمها
                shouldOverrideUrlLoading: (c, action) async {
                  final scheme = action.request.url?.scheme ?? '';
                  const ok = ['http', 'https', 'file', 'about', 'data', 'blob', 'javascript'];
                  if (!ok.contains(scheme)) return NavigationActionPolicy.CANCEL;
                  return NavigationActionPolicy.ALLOW;
                },

                // لقط التحميل
                onDownloadStartRequest: (c, req) async {
                  final url = req.url.toString();
                  final headers = <String, String>{
                    if (req.userAgent != null && req.userAgent!.isNotEmpty)
                      'User-Agent': req.userAgent!,
                  };
                  final name = (req.suggestedFilename != null &&
                          req.suggestedFilename!.trim().isNotEmpty)
                      ? sanitizeName(req.suggestedFilename!)
                      : nameFromContentDisposition(req.contentDisposition);
                  await _offer(
                    url,
                    headers,
                    name: name,
                    size: req.contentLength > 0 ? req.contentLength : 0,
                  );
                },

                // اكتشاف ملفات الميديا من طلبات الشبكة (أندرويد)
                shouldInterceptRequest: (c, request) async {
                  try {
                    final u = request.url;
                    final path = u.path.toLowerCase();
                    final dot = path.lastIndexOf('.');
                    if (dot > 0 && _mediaExt.contains(path.substring(dot + 1))) {
                      final key = u.toString();
                      if (!_found.containsKey(key) && _found.length < 60) {
                        final h = <String, String>{};
                        request.headers?.forEach((k, v) {
                          final lk = k.toLowerCase();
                          if (lk == 'user-agent' || lk == 'referer' || lk == 'cookie') {
                            h[k] = v;
                          }
                        });
                        _found[key] = h;
                        if (mounted) setState(() {});
                      }
                    }
                  } catch (_) {}
                  return null;
                },
              ),
            ),
          ],
        ),
        bottomNavigationBar: Material(
          color: Theme.of(context).colorScheme.surfaceContainer,
          child: SafeArea(
            top: false,
            child: SizedBox(
              height: 52,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back),
                    onPressed: () => _c?.goBack(),
                  ),
                  IconButton(
                    icon: const Icon(Icons.arrow_forward),
                    onPressed: () => _c?.goForward(),
                  ),
                  IconButton(
                    icon: const Icon(Icons.refresh),
                    onPressed: () => _c?.reload(),
                  ),
                  IconButton(
                    icon: const Icon(Icons.home_outlined),
                    onPressed: () => _go('https://www.google.com'),
                  ),
                  IconButton(
                    tooltip: 'رجوع للتحميلات',
                    icon: const Icon(Icons.download_done),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
