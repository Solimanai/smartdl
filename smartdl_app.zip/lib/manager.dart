import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'background.dart';
import 'engine.dart';
import 'models.dart';
import 'settings.dart';
import 'utils.dart';

class DownloadManager extends ChangeNotifier {
  DownloadManager(this.settings);

  final AppSettings settings;
  final SpeedLimiter limiter = SpeedLimiter();
  final List<DownloadItem> items = [];
  final Map<String, DownloadTask> _tasks = {};
  final Map<String, Future<void>> _runs = {};

  late File _store;
  Timer? _timer;
  int _tick = 0;
  bool _dirty = false;
  bool _saving = false;

  int get activeCount => _tasks.length;
  double get totalSpeed => items
      .where((i) => i.status == DlStatus.downloading)
      .fold(0.0, (a, i) => a + i.speed);

  Future<void> init() async {
    final dir = await getApplicationSupportDirectory();
    _store = File(p.join(dir.path, 'downloads.json'));
    if (await _store.exists()) {
      try {
        final list = jsonDecode(await _store.readAsString()) as List;
        for (final j in list) {
          items.add(DownloadItem.fromJson(Map<String, dynamic>.from(j as Map)));
        }
      } catch (_) {}
    }
    for (final it in items) {
      // لو البرنامج اتقفل وهو بيحمّل، كمّل أوتوماتيك
      if (it.status == DlStatus.downloading) it.status = DlStatus.queued;
      it.recomputeBytes(() {
        try {
          final f = File(it.partPath);
          return f.existsSync() ? f.lengthSync() : 0;
        } catch (_) {
          return 0;
        }
      });
    }
    _applyLimit();
    settings.addListener(() {
      _applyLimit();
      _pump();
    });
    _timer = Timer.periodic(const Duration(milliseconds: 500), (_) => _onTick());
    _pump();
  }

  void _applyLimit() => limiter.limit = settings.speedLimitKB * 1024;

  void _onTick() {
    var any = false;
    for (final it in items) {
      if (it.status == DlStatus.downloading) {
        final d = it.bytesDone - it.lastBytes;
        it.lastBytes = it.bytesDone;
        it.speed = it.speed * 0.6 + (d / 0.5) * 0.4;
        any = true;
      } else {
        it.speed = 0;
      }
    }
    _tick++;
    if (_tick % 6 == 0) {
      if (any || _dirty) _save();
      Background.update(
        _tasks.length,
        '${_tasks.length} تحميل • ${humanBytes(totalSpeed)}/ث',
      );
    }
    if (any) notifyListeners();
  }

  Set<String> _taken(String dir, {String? except}) => items
      .where((i) => i.id != except && i.dir == dir)
      .map((i) => i.fileName)
      .toSet();

  Future<DownloadItem> add(
    String url, {
    Map<String, String>? headers,
    String? fileName,
  }) async {
    // لو نفس الرابط موجود ومش مكتمل، كمّله بدل التكرار
    final dup = items.where((i) => i.url == url && i.status != DlStatus.completed);
    if (dup.isNotEmpty) {
      final it = dup.first;
      if (headers != null && headers.isNotEmpty) it.headers = headers;
      resume(it.id);
      return it;
    }
    final dir = await settings.resolveDir();
    final fixed = fileName != null && fileName.trim().isNotEmpty;
    final name = uniqueName(
      dir,
      sanitizeName(fixed ? fileName : nameFromUrl(url)),
      _taken(dir),
      (path) => File(path).existsSync() || File('$path.part').existsSync(),
    );
    final it = DownloadItem(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      url: url,
      headers: headers,
      fileName: name,
      dir: dir,
      fixedName: fixed,
    );
    items.add(it);
    _dirty = true;
    await _save();
    _pump();
    return it;
  }

  void _pump() {
    while (_tasks.length < settings.maxConcurrent) {
      DownloadItem? next;
      for (final i in items) {
        if (i.status == DlStatus.queued && !_tasks.containsKey(i.id)) {
          next = i;
          break;
        }
      }
      if (next == null) break;
      _start(next);
    }
    notifyListeners();
  }

  void _start(DownloadItem it) {
    it.status = DlStatus.downloading;
    it.error = null;
    it.note = null;
    final task = DownloadTask(
      it,
      settings,
      limiter,
      onTick: () => _dirty = true,
      uniqueFor: (desired) => uniqueName(
        it.dir,
        desired,
        _taken(it.dir, except: it.id),
        (path) => File(path).existsSync(),
      ),
    );
    _tasks[it.id] = task;
    _runs[it.id] = task.run().whenComplete(() {
      _tasks.remove(it.id);
      _runs.remove(it.id);
      _dirty = true;
      _save();
      _syncWake();
      _pump();
    });
    _syncWake();
  }

  void _syncWake() {
    try {
      WakelockPlus.toggle(enable: _tasks.isNotEmpty);
    } catch (_) {}
    if (_tasks.isEmpty) Background.update(0, '');
  }

  void pause(String id) {
    final it = _byId(id);
    if (it == null) return;
    if (it.status == DlStatus.downloading || it.status == DlStatus.queued) {
      it.status = DlStatus.paused;
      it.speed = 0;
      _tasks[id]?.stop();
      _dirty = true;
      notifyListeners();
    }
  }

  void resume(String id) {
    final it = _byId(id);
    if (it == null) return;
    if (it.status == DlStatus.paused || it.status == DlStatus.failed) {
      it.status = DlStatus.queued;
      it.error = null;
      _dirty = true;
      // لو المهمة القديمة لسه بتقفل، استنى لحد ما تخلص
      final running = _runs[id];
      if (running != null) {
        running.whenComplete(_pump);
        notifyListeners();
      } else {
        _pump();
      }
    }
  }

  void pauseAll() {
    for (final it in List.of(items)) {
      pause(it.id);
    }
  }

  void resumeAll() {
    for (final it in List.of(items)) {
      resume(it.id);
    }
  }

  Future<void> restart(String id) async {
    final it = _byId(id);
    if (it == null) return;
    _tasks[id]?.stop();
    await _runs[id];
    try {
      final f = File(it.partPath);
      if (await f.exists()) await f.delete();
      if (it.status == DlStatus.completed) {
        final done = File(it.path);
        if (await done.exists()) await done.delete();
      }
    } catch (_) {}
    it.doneChunks.clear();
    it.chunkGot.clear();
    it.chunkSize = 0;
    it.totalBytes = 0;
    it.bytesDone = 0;
    it.lastBytes = 0;
    it.status = DlStatus.queued;
    it.error = null;
    _dirty = true;
    _pump();
  }

  Future<void> remove(String id, {required bool deleteFile}) async {
    final it = _byId(id);
    if (it == null) return;
    _tasks[id]?.stop();
    await _runs[id];
    items.removeWhere((i) => i.id == id);
    try {
      final part = File(it.partPath);
      if (await part.exists()) await part.delete();
      if (deleteFile) {
        final f = File(it.path);
        if (await f.exists()) await f.delete();
      }
    } catch (_) {}
    _dirty = true;
    await _save();
    notifyListeners();
  }

  DownloadItem? _byId(String id) {
    for (final i in items) {
      if (i.id == id) return i;
    }
    return null;
  }

  Future<void> _save() async {
    if (_saving) return;
    _saving = true;
    try {
      _dirty = false;
      final tmp = File('${_store.path}.tmp');
      await tmp.writeAsString(jsonEncode(items.map((e) => e.toJson()).toList()));
      await tmp.rename(_store.path);
    } catch (e) {
      if (kDebugMode) debugPrint('save failed: $e');
    } finally {
      _saving = false;
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
