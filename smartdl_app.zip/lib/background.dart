import 'dart:io';

import 'package:flutter_foreground_task/flutter_foreground_task.dart';

/// خدمة أمامية على أندرويد علشان التحميل يكمل والتطبيق في الخلفية أو الشاشة مقفولة.
class Background {
  static bool _running = false;
  static bool _busy = false;

  static Future<void> init() async {
    if (!Platform.isAndroid) return;
    try {
      final permission = await FlutterForegroundTask.checkNotificationPermission();
      if (permission != NotificationPermission.granted) {
        await FlutterForegroundTask.requestNotificationPermission();
      }
      FlutterForegroundTask.init(
        androidNotificationOptions: AndroidNotificationOptions(
          channelId: 'smartdl_downloads',
          channelName: 'التحميلات',
          channelDescription: 'بيظهر وقت التحميل علشان التحميل يكمل في الخلفية.',
          onlyAlertOnce: true,
        ),
        iosNotificationOptions: const IOSNotificationOptions(
          showNotification: false,
          playSound: false,
        ),
        foregroundTaskOptions: ForegroundTaskOptions(
          eventAction: ForegroundTaskEventAction.repeat(5000),
          autoRunOnBoot: false,
          autoRunOnMyPackageReplaced: false,
          allowWakeLock: true,
          allowWifiLock: true,
        ),
      );
    } catch (_) {}
  }

  static Future<void> update(int active, String text) async {
    if (!Platform.isAndroid || _busy) return;
    _busy = true;
    try {
      if (active > 0) {
        if (!_running) {
          _running = true;
          await FlutterForegroundTask.startService(
            serviceId: 256,
            notificationTitle: 'SmartDL',
            notificationText: text,
            callback: startCallback,
          );
        } else {
          await FlutterForegroundTask.updateService(
            notificationTitle: 'SmartDL',
            notificationText: text,
          );
        }
      } else if (_running) {
        _running = false;
        await FlutterForegroundTask.stopService();
      }
    } catch (_) {
    } finally {
      _busy = false;
    }
  }
}

@pragma('vm:entry-point')
void startCallback() {
  FlutterForegroundTask.setTaskHandler(_KeepAliveHandler());
}

class _KeepAliveHandler extends TaskHandler {
  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {}

  @override
  void onRepeatEvent(DateTime timestamp) {}

  @override
  Future<void> onDestroy(DateTime timestamp, bool isTimeout) async {}
}
