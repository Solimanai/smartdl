import 'package:path/path.dart' as p;

const kDefaultUA =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

String humanBytes(num n) {
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  var v = n.toDouble();
  var i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return '${v.toStringAsFixed(i == 0 ? 0 : 1)} ${units[i]}';
}

String humanEta(double secs) {
  if (secs.isNaN || secs.isInfinite || secs <= 0) return '--';
  final s = secs.round();
  if (s < 60) return '$s ث';
  if (s < 3600) return '${s ~/ 60} د ${s % 60} ث';
  return '${s ~/ 3600} س ${(s % 3600) ~/ 60} د';
}

String shorten(String s, [int n = 48]) =>
    s.length <= n ? s : '${s.substring(0, n - 1)}…';

bool isHttpUrl(String s) {
  final u = Uri.tryParse(s.trim());
  return u != null && (u.scheme == 'http' || u.scheme == 'https') && u.host.isNotEmpty;
}

String sanitizeName(String name) {
  var n = name.replaceAll(RegExp(r'[<>:"/\\|?*\x00-\x1f]'), '_').trim();
  n = n.replaceAll(RegExp(r'^\.+'), '');
  if (n.isEmpty) n = 'download';
  if (n.length > 180) {
    final ext = p.extension(n);
    n = n.substring(0, 170) + (ext.length <= 10 ? ext : '');
  }
  return n;
}

String nameFromUrl(String url) {
  try {
    final u = Uri.parse(url);
    final seg = u.pathSegments.where((s) => s.isNotEmpty).toList();
    if (seg.isNotEmpty) return sanitizeName(Uri.decodeComponent(seg.last));
  } catch (_) {}
  return 'download';
}

String? nameFromContentDisposition(String? cd) {
  if (cd == null) return null;
  final m1 = RegExp(r"filename\*\s*=\s*([^']*)'[^']*'([^;]+)", caseSensitive: false)
      .firstMatch(cd);
  if (m1 != null) {
    try {
      return sanitizeName(Uri.decodeComponent(m1.group(2)!.trim()));
    } catch (_) {}
  }
  final m2 =
      RegExp(r'filename\s*=\s*"?([^";]+)"?', caseSensitive: false).firstMatch(cd);
  if (m2 != null) return sanitizeName(m2.group(1)!.trim());
  return null;
}

const _mimeExt = {
  'video/mp4': '.mp4',
  'video/webm': '.webm',
  'video/x-matroska': '.mkv',
  'audio/mpeg': '.mp3',
  'audio/mp4': '.m4a',
  'application/zip': '.zip',
  'application/x-rar-compressed': '.rar',
  'application/x-7z-compressed': '.7z',
  'application/pdf': '.pdf',
  'application/vnd.android.package-archive': '.apk',
  'application/x-msdownload': '.exe',
  'application/x-iso9660-image': '.iso',
};

String withExtFromMime(String name, String? mime) {
  if (p.extension(name).isNotEmpty || mime == null) return name;
  final e = _mimeExt[mime];
  return e == null ? name : '$name$e';
}

/// اسم ملف غير مكرر (بيزوّد " (1)" لو موجود).
String uniqueName(String dir, String name, Set<String> taken, bool Function(String) exists) {
  final base = p.basenameWithoutExtension(name);
  final ext = p.extension(name);
  var candidate = name;
  var i = 1;
  while (taken.contains(candidate) || exists(p.join(dir, candidate))) {
    candidate = '$base ($i)$ext';
    i++;
  }
  return candidate;
}
