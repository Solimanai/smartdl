import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSettings extends ChangeNotifier {
  int connections = 8; // عدد الاتصالات لكل ملف
  int maxConcurrent = 3; // عدد التحميلات في نفس الوقت
  int speedLimitKB = 0; // 0 = بدون حد
  String? customDir;
  bool blockPopups = true;
  bool confirmCapture = true;

  late SharedPreferences _sp;

  static Future<AppSettings> load() async {
    final s = AppSettings();
    s._sp = await SharedPreferences.getInstance();
    s.connections = s._sp.getInt('connections') ?? 8;
    s.maxConcurrent = s._sp.getInt('maxConcurrent') ?? 3;
    s.speedLimitKB = s._sp.getInt('speedLimitKB') ?? 0;
    s.customDir = s._sp.getString('customDir');
    s.blockPopups = s._sp.getBool('blockPopups') ?? true;
    s.confirmCapture = s._sp.getBool('confirmCapture') ?? true;
    return s;
  }

  Future<void> save() async {
    await _sp.setInt('connections', connections);
    await _sp.setInt('maxConcurrent', maxConcurrent);
    await _sp.setInt('speedLimitKB', speedLimitKB);
    if (customDir == null) {
      await _sp.remove('customDir');
    } else {
      await _sp.setString('customDir', customDir!);
    }
    await _sp.setBool('blockPopups', blockPopups);
    await _sp.setBool('confirmCapture', confirmCapture);
    notifyListeners();
  }

  Future<String> defaultDir() async {
    Directory? base;
    try {
      if (Platform.isAndroid) {
        base = await getExternalStorageDirectory();
      } else {
        base = await getDownloadsDirectory();
      }
    } catch (_) {}
    base ??= await getApplicationDocumentsDirectory();
    return p.join(base.path, 'SmartDL');
  }

  Future<String> resolveDir() async {
    final c = customDir;
    if (c != null && c.isNotEmpty) return c;
    return defaultDir();
  }
}
