import 'dart:math';

import 'package:path/path.dart' as p;

enum DlStatus { queued, downloading, paused, completed, failed }

class DownloadItem {
  DownloadItem({
    required this.id,
    required this.url,
    required this.fileName,
    required this.dir,
    Map<String, String>? headers,
    this.totalBytes = 0,
    this.rangeSupported = false,
    this.chunkSize = 0,
    this.fixedName = false,
    this.status = DlStatus.queued,
    this.error,
    int? createdAt,
    Set<int>? doneChunks,
    Map<int, int>? chunkGot,
  })  : headers = headers ?? {},
        doneChunks = doneChunks ?? <int>{},
        chunkGot = chunkGot ?? <int, int>{},
        createdAt = createdAt ?? DateTime.now().millisecondsSinceEpoch;

  final String id;
  String url;
  Map<String, String> headers;
  String fileName;
  String dir;
  int totalBytes; // 0 = غير معروف
  bool rangeSupported;
  int chunkSize;
  bool fixedName;
  DlStatus status;
  String? error;
  final int createdAt;
  Set<int> doneChunks;
  Map<int, int> chunkGot;

  // بيانات وقت التشغيل فقط (مش بتتحفظ)
  int bytesDone = 0;
  double speed = 0;
  int lastBytes = 0;
  String? note;

  String get path => p.join(dir, fileName);
  String get partPath => '$path.part';

  double? get progress =>
      totalBytes > 0 ? (bytesDone / totalBytes).clamp(0.0, 1.0).toDouble() : null;

  int chunkLen(int i) => min(chunkSize, totalBytes - i * chunkSize);

  void recomputeBytes(int Function() partLength) {
    if (status == DlStatus.completed) {
      bytesDone = totalBytes;
    } else if (chunkSize > 0 && totalBytes > 0) {
      var s = 0;
      for (final i in doneChunks) {
        s += chunkLen(i);
      }
      for (final v in chunkGot.values) {
        s += v;
      }
      bytesDone = s;
    } else {
      bytesDone = partLength();
    }
    lastBytes = bytesDone;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'url': url,
        'headers': headers,
        'fileName': fileName,
        'dir': dir,
        'totalBytes': totalBytes,
        'rangeSupported': rangeSupported,
        'chunkSize': chunkSize,
        'fixedName': fixedName,
        'status': status.name,
        'error': error,
        'createdAt': createdAt,
        'doneChunks': doneChunks.toList(),
        'chunkGot': chunkGot.map((k, v) => MapEntry(k.toString(), v)),
      };

  factory DownloadItem.fromJson(Map<String, dynamic> j) => DownloadItem(
        id: j['id'] as String,
        url: j['url'] as String,
        headers: (j['headers'] as Map? ?? {}).map((k, v) => MapEntry('$k', '$v')),
        fileName: j['fileName'] as String,
        dir: j['dir'] as String,
        totalBytes: (j['totalBytes'] as num?)?.toInt() ?? 0,
        rangeSupported: j['rangeSupported'] as bool? ?? false,
        chunkSize: (j['chunkSize'] as num?)?.toInt() ?? 0,
        fixedName: j['fixedName'] as bool? ?? false,
        status: DlStatus.values.firstWhere(
          (s) => s.name == j['status'],
          orElse: () => DlStatus.queued,
        ),
        error: j['error'] as String?,
        createdAt: (j['createdAt'] as num?)?.toInt(),
        doneChunks: ((j['doneChunks'] as List?) ?? []).map((e) => (e as num).toInt()).toSet(),
        chunkGot: ((j['chunkGot'] as Map?) ?? {})
            .map((k, v) => MapEntry(int.parse('$k'), (v as num).toInt())),
      );
}
