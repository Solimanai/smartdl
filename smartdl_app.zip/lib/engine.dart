import 'dart:async';
import 'dart:collection';
import 'dart:io';
import 'dart:math';

import 'models.dart';
import 'settings.dart';
import 'utils.dart';

// ───────────────────────── أخطاء ─────────────────────────

class HttpFail implements Exception {
  HttpFail(this.code);
  final int code;
  @override
  String toString() => 'HTTP $code';
}

class _Stopped implements Exception {}

/// أخطاء مفيش فايدة من إعادة المحاولة معاها.
bool _isFatal(int code) =>
    code >= 400 && code < 500 && code != 408 && code != 429;

String friendlyError(Object e) {
  if (e is HttpFail) {
    switch (e.code) {
      case 401:
      case 403:
        return 'السيرفر رفض الطلب (${e.code}). الرابط ممكن يكون انتهت صلاحيته أو محتاج تسجيل دخول، افتحه من المتصفح تاني.';
      case 404:
      case 410:
        return 'الملف مش موجود على السيرفر (${e.code}).';
      case 416:
        return 'الملف اتغير على السيرفر. اختار "إعادة من الصفر".';
      default:
        return 'خطأ من السيرفر (HTTP ${e.code}).';
    }
  }
  if (e is FileSystemException) {
    return 'مشكلة في الملف أو المساحة: ${e.osError?.message ?? e.message}';
  }
  final s = e.toString();
  return s.startsWith('Exception: ') ? s.substring(11) : s;
}

// ───────────────────────── فحص الرابط ─────────────────────────

class ProbeResult {
  ProbeResult({
    required this.size,
    required this.ranges,
    required this.fileName,
    required this.isHtml,
  });
  final int size; // 0 = غير معروف
  final bool ranges;
  final String? fileName;
  final bool isHtml;
}

HttpClient _makeClient(Map<String, String> headers) {
  final c = HttpClient();
  c.connectionTimeout = const Duration(seconds: 15);
  c.idleTimeout = const Duration(seconds: 20);
  c.autoUncompress = false; // مهم علشان الـ Range يشتغل صح
  c.userAgent = headers['User-Agent'] ?? headers['user-agent'] ?? kDefaultUA;
  return c;
}

void _applyHeaders(HttpClientRequest req, Map<String, String> headers) {
  req.followRedirects = true;
  req.maxRedirects = 10;
  req.headers.set(HttpHeaders.acceptEncodingHeader, 'identity');
  headers.forEach((k, v) {
    final lk = k.toLowerCase();
    if (lk == 'range' || lk == 'host' || lk == 'content-length' || lk == 'accept-encoding') {
      return;
    }
    req.headers.set(k, v);
  });
}

Future<ProbeResult> probeUrl(String url, Map<String, String> headers) async {
  final client = _makeClient(headers);
  try {
    final req = await client.getUrl(Uri.parse(url));
    _applyHeaders(req, headers);
    req.headers.set(HttpHeaders.rangeHeader, 'bytes=0-0');
    final resp = await req.close().timeout(const Duration(seconds: 25));
    final code = resp.statusCode;
    final mime = resp.headers.contentType?.mimeType.toLowerCase();
    final cd = resp.headers.value('content-disposition');

    var size = 0;
    var ranges = false;
    if (code == 206) {
      ranges = true;
      final cr = resp.headers.value(HttpHeaders.contentRangeHeader) ?? '';
      final m = RegExp(r'/(\d+)\s*$').firstMatch(cr);
      size = m != null ? int.parse(m.group(1)!) : 0;
    } else if (code == 200) {
      size = resp.contentLength > 0 ? resp.contentLength : 0;
    } else {
      await resp.listen((_) {}).cancel();
      throw HttpFail(code);
    }

    var finalUri = Uri.parse(url);
    if (resp.redirects.isNotEmpty) {
      finalUri = finalUri.resolveUri(resp.redirects.last.location);
    }
    var name = nameFromContentDisposition(cd) ?? nameFromUrl(finalUri.toString());
    name = withExtFromMime(name, mime);
    final lower = name.toLowerCase();
    final isHtml = mime == 'text/html' &&
        cd == null &&
        !lower.endsWith('.html') &&
        !lower.endsWith('.htm');

    await resp.listen((_) {}).cancel();
    return ProbeResult(size: size, ranges: ranges, fileName: name, isHtml: isHtml);
  } finally {
    client.close(force: true);
  }
}

// ───────────────────────── حد السرعة ─────────────────────────

class SpeedLimiter {
  int limit = 0; // بايت/ثانية، 0 = بدون حد
  int _used = 0;
  int _windowStart = DateTime.now().millisecondsSinceEpoch;

  Future<void> take(int n) async {
    if (limit <= 0) return;
    while (true) {
      final now = DateTime.now().millisecondsSinceEpoch;
      if (now - _windowStart >= 1000) {
        _windowStart = now;
        _used = 0;
      }
      if (_used < limit) {
        _used += n;
        return;
      }
      await Future.delayed(Duration(milliseconds: max(5, 1000 - (now - _windowStart))));
    }
  }
}

// ───────────────────────── مهمة التحميل ─────────────────────────

class DownloadTask {
  DownloadTask(
    this.item,
    this.settings,
    this.limiter, {
    required this.onTick,
    required this.uniqueFor,
  });

  final DownloadItem item;
  final AppSettings settings;
  final SpeedLimiter limiter;
  final void Function() onTick;
  final String Function(String desired) uniqueFor;

  bool _stop = false; // المستخدم وقّف
  bool _abort = false; // خطأ قاتل في worker
  Object? _fatal;
  final List<HttpClient> _clients = [];

  bool get _halt => _stop || _abort;

  HttpClient _track(HttpClient c) {
    _clients.add(c);
    return c;
  }

  void _closeClients() {
    for (final c in List.of(_clients)) {
      try {
        c.close(force: true);
      } catch (_) {}
    }
  }

  /// إيقاف مؤقت (الحالة بيحددها المدير).
  void stop() {
    _stop = true;
    _closeClients();
  }

  Future<void> _sleep(int seconds) async {
    for (var i = 0; i < seconds * 4 && !_halt; i++) {
      await Future.delayed(const Duration(milliseconds: 250));
    }
  }

  Future<void> run() async {
    item.status = DlStatus.downloading;
    item.error = null;
    try {
      await Directory(item.dir).create(recursive: true);
      final pr = await _probeWithRetry();
      if (_stop) return;
      if (pr.isHtml) {
        throw Exception('الرابط ده صفحة ويب مش ملف. افتحه من المتصفح المدمج.');
      }

      // لو الملف اتغير على السيرفر ابدأ من الأول
      if ((item.totalBytes != 0 && pr.size != item.totalBytes) ||
          ((!pr.ranges || pr.size == 0) && item.doneChunks.isNotEmpty)) {
        await _resetProgress();
      }
      item.totalBytes = pr.size;
      item.rangeSupported = pr.ranges;

      // اسم أفضل من السيرفر (لو لسه مبدأناش)
      if (item.bytesDone == 0 && !item.fixedName && pr.fileName != null && pr.fileName != item.fileName) {
        final old = File(item.partPath);
        if (await old.exists()) await old.delete();
        item.fileName = uniqueFor(pr.fileName!);
      }

      if (pr.ranges && pr.size > 0) {
        await _runSegmented();
      } else {
        await _runSingle(pr);
      }
      if (_stop) return;
      await _finalize();
    } on _Stopped {
      return;
    } catch (e) {
      if (!_stop) {
        item.status = DlStatus.failed;
        item.error = friendlyError(e);
      }
    } finally {
      _closeClients();
      onTick();
    }
  }

  Future<ProbeResult> _probeWithRetry() async {
    var delay = 1;
    while (!_stop) {
      try {
        return await probeUrl(item.url, item.headers);
      } on HttpFail catch (e) {
        if (_isFatal(e.code)) rethrow;
        item.note = 'السيرفر مشغول (${e.code})، بحاول تاني...';
      } catch (_) {
        item.note = 'مفيش اتصال، بحاول تاني...';
      }
      onTick();
      await _sleep(min(delay, 20));
      delay = min(delay * 2, 20);
    }
    throw _Stopped();
  }

  Future<void> _resetProgress() async {
    final part = File(item.partPath);
    if (await part.exists()) await part.delete();
    item.doneChunks.clear();
    item.chunkGot.clear();
    item.chunkSize = 0;
    item.bytesDone = 0;
    item.lastBytes = 0;
  }

  // ───────── تحميل بمقاطع متوازية ─────────

  Future<void> _runSegmented() async {
    final total = item.totalBytes;
    final part = File(item.partPath);

    if (item.chunkSize == 0) {
      var cs = max(1 << 20, (total / 256).ceil());
      cs = ((cs + 65535) ~/ 65536) * 65536;
      item.chunkSize = cs;
    }

    final partOk = await part.exists() && await part.length() == total;
    if (!partOk) {
      item.doneChunks.clear();
      item.chunkGot.clear();
      item.bytesDone = 0;
      item.lastBytes = 0;
      final raf = await part.open(mode: FileMode.write);
      await raf.truncate(total); // حجز المساحة مرة واحدة
      await raf.close();
    }

    final count = (total + item.chunkSize - 1) ~/ item.chunkSize;
    final pending = Queue<int>()
      ..addAll([
        for (var i = 0; i < count; i++)
          if (!item.doneChunks.contains(i)) i
      ]);
    if (pending.isNotEmpty) {
      final workers = max(1, min(settings.connections, pending.length));
      await Future.wait([for (var i = 0; i < workers; i++) _worker(pending, part)]);
    }
    if (_fatal != null) throw _fatal!;
    if (_stop) return;
    if (item.doneChunks.length != count) {
      throw Exception('التحميل ناقص، جرب تاني.');
    }
  }

  Future<void> _worker(Queue<int> pending, File part) async {
    final client = _track(_makeClient(item.headers));
    RandomAccessFile? raf;
    try {
      // FileMode.append بيفتح الملف بدون ما يمسحه، و setPosition بيسمح بالكتابة في أي مكان.
      raf = await part.open(mode: FileMode.append);
      while (!_halt && pending.isNotEmpty) {
        final idx = pending.removeFirst();
        await _fetchChunk(client, raf, idx);
      }
    } catch (e) {
      if (!_stop) {
        _fatal ??= e;
        _abort = true;
        _closeClients();
      }
    } finally {
      try {
        await raf?.close();
      } catch (_) {}
      client.close(force: true);
    }
  }

  Future<void> _fetchChunk(HttpClient client, RandomAccessFile raf, int idx) async {
    final cs = item.chunkSize;
    final start = idx * cs;
    final len = min(cs, item.totalBytes - start);
    final end = start + len - 1;
    var got = item.chunkGot[idx] ?? 0;
    var delay = 1;
    var fails = 0;

    while (!_halt) {
      var progressed = false;
      try {
        final req = await client.getUrl(Uri.parse(item.url));
        _applyHeaders(req, item.headers);
        req.headers.set(HttpHeaders.rangeHeader, 'bytes=${start + got}-$end');
        final resp = await req.close().timeout(const Duration(seconds: 30));
        if (resp.statusCode != 206) {
          final code = resp.statusCode;
          await resp.listen((_) {}).cancel();
          throw HttpFail(code);
        }

        final buf = BytesBuilder();
        var pos = start + got;
        var remaining = len - got;

        Future<void> flush() async {
          if (buf.isEmpty) return;
          final data = buf.takeBytes();
          await raf.setPosition(pos);
          await raf.writeFrom(data);
          pos += data.length;
          got += data.length;
          item.chunkGot[idx] = got;
          item.bytesDone += data.length;
          item.note = null;
          onTick();
        }

        await for (final piece in resp.timeout(const Duration(seconds: 30))) {
          if (_halt) break;
          var data = piece;
          if (data.length > remaining) data = data.sublist(0, remaining);
          if (data.isEmpty) break;
          await limiter.take(data.length);
          buf.add(data);
          remaining -= data.length;
          progressed = true;
          if (buf.length >= 512 * 1024) await flush();
          if (remaining <= 0) break;
        }
        await flush();

        if (got >= len) {
          item.doneChunks.add(idx);
          item.chunkGot.remove(idx);
          return;
        }
        if (_halt) return;
        throw const SocketException('short read');
      } on HttpFail catch (e) {
        if (_isFatal(e.code)) rethrow;
        item.note = 'السيرفر مشغول (${e.code})، بحاول تاني...';
      } on FileSystemException catch (_) {
        rethrow;
      } catch (_) {
        if (_halt) return;
        item.note = 'الاتصال اتقطع، بحاول تاني...';
      }

      if (progressed) {
        delay = 1;
        fails = 0;
      } else {
        fails++;
        if (fails > 600) throw Exception('فشل بعد محاولات كتير، تأكد من الاتصال.');
      }
      await _sleep(delay);
      delay = min(delay * 2, 20);
    }
  }

  // ───────── تحميل عادي (stream واحد) ─────────

  Future<void> _runSingle(ProbeResult pr) async {
    final part = File(item.partPath);
    final total = item.totalBytes;
    var delay = 1;
    var fails = 0;

    while (!_halt) {
      var progressed = false;
      var pos = 0;
      final exists = await part.exists();
      if (pr.ranges && exists) {
        pos = await part.length();
      } else if (exists) {
        await part.delete();
      }
      if (total > 0 && pos > total) {
        await part.delete();
        pos = 0;
      }
      item.bytesDone = pos;
      item.lastBytes = pos;
      if (total > 0 && pos == total) return;

      RandomAccessFile? raf;
      try {
        final client = _track(_makeClient(item.headers));
        final req = await client.getUrl(Uri.parse(item.url));
        _applyHeaders(req, item.headers);
        if (pos > 0) req.headers.set(HttpHeaders.rangeHeader, 'bytes=$pos-');
        final resp = await req.close().timeout(const Duration(seconds: 30));
        final code = resp.statusCode;
        if (pos > 0 && code != 206) {
          // السيرفر تجاهل الاستئناف: ابدأ من الصفر
          await resp.listen((_) {}).cancel();
          await part.delete();
          continue;
        }
        if (code != 200 && code != 206) {
          await resp.listen((_) {}).cancel();
          throw HttpFail(code);
        }
        raf = await part.open(mode: pos > 0 ? FileMode.append : FileMode.write);
        await for (final piece in resp.timeout(const Duration(seconds: 30))) {
          if (_halt) break;
          await limiter.take(piece.length);
          await raf.writeFrom(piece);
          pos += piece.length;
          item.bytesDone = pos;
          item.note = null;
          progressed = true;
          onTick();
        }
        await raf.close();
        raf = null;
        if (_halt) return;
        if (total == 0 || pos >= total) return;
        throw const SocketException('short read');
      } on HttpFail catch (e) {
        if (_isFatal(e.code)) rethrow;
        item.note = 'السيرفر مشغول (${e.code})، بحاول تاني...';
      } on FileSystemException catch (_) {
        rethrow;
      } catch (_) {
        if (_halt) return;
        item.note = 'الاتصال اتقطع، بحاول تاني...';
      } finally {
        try {
          await raf?.close();
        } catch (_) {}
      }

      if (progressed) {
        delay = 1;
        fails = 0;
      } else {
        fails++;
        if (fails > 600) throw Exception('فشل بعد محاولات كتير، تأكد من الاتصال.');
      }
      await _sleep(delay);
      delay = min(delay * 2, 20);
    }
  }

  // ───────── إنهاء ─────────

  Future<void> _finalize() async {
    final part = File(item.partPath);
    final len = await part.length();
    if (item.totalBytes > 0) {
      if (len != item.totalBytes) {
        throw Exception('حجم الملف النهائي مش مطابق للمتوقع.');
      }
    } else {
      item.totalBytes = len;
    }
    if (await File(item.path).exists()) {
      final old = item.fileName;
      final newName = uniqueFor(old);
      final from = item.partPath;
      item.fileName = newName;
      await File(from).rename(item.partPath);
    }
    await File(item.partPath).rename(item.path);
    item.status = DlStatus.completed;
    item.doneChunks.clear();
    item.chunkGot.clear();
    item.bytesDone = item.totalBytes;
    item.note = null;
    item.error = null;
  }
}
