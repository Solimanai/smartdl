import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'app_state.dart';
import 'background.dart';
import 'manager.dart';
import 'settings.dart';
import 'ui/home_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  if (Platform.isAndroid) {
    FlutterForegroundTask.initCommunicationPort();
  }

  if (Platform.isWindows) {
    try {
      final support = await getApplicationSupportDirectory();
      App.webEnv = await WebViewEnvironment.create(
        settings: WebViewEnvironmentSettings(
          userDataFolder: p.join(support.path, 'webview'),
        ),
      );
    } catch (_) {
      // WebView2 Runtime مش متسطّب: المتصفح المدمج مش هيشتغل لكن باقي البرنامج شغال.
    }
  }

  App.settings = await AppSettings.load();
  App.manager = DownloadManager(App.settings);
  await Background.init();
  await App.manager.init();

  runApp(const SmartDlApp());
}

class SmartDlApp extends StatelessWidget {
  const SmartDlApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SmartDL',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      themeMode: ThemeMode.system,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2563EB),
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2563EB),
        brightness: Brightness.dark,
      ),
      home: const HomePage(),
    );
  }
}
